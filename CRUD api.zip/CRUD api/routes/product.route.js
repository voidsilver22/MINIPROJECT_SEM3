// Imports: It imports the required libraries and modules like express and the Product model.
const express = require("express");
const Product = require("../models/product.model.js");
const router = express.Router();
const {getProducts,getProduct, createProduct, updatedProduct, deleteProduct} = require('../controllers/product.controller.js');

// Router Creation: Creates an instance of the Express router.
// Route Handlers: Defines routes for handling CRUD operations on products using functions from product.controller.js.

router.get('/',getProducts);
router.get("/:id", getProduct);

router.post("/", createProduct);

// update a product
router.put("/:id", updatedProduct);

//Delete a product
router.delete("/:id", deleteProduct);

// Exports: Exports the router instance.
module.exports = router;