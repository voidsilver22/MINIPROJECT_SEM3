// Imports: It imports the mongoose library, which helps in defining the schema for MongoDB documents
const mongoose = require("mongoose");


// Schema Definition: It defines the structure of the Product schema using mongoose.Schema(). It includes fields like name, quantity, price, and image.

const ProductSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Please enter product name"],
    },

    quantity: {
      type: Number,
      required: true,
      default: 0,
    },

    price: {
      type: Number,
      required: true,
      default: 0,
    },

    image: {
      type: String,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

// Model Creation: It creates a mongoose model named Product based on the defined schema.
const Product = mongoose.model("Product", ProductSchema);

// Exports: It exports the Product model.
module.exports = Product;

